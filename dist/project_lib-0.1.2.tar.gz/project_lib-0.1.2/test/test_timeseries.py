from project_lib import TimeSeries

def test_basic():
    ts = TimeSeries([1, 2, 3])
    assert len(ts.data) == 3
