from .timeseries import TimeSeries

__all__ = ["TimeSeries"]

__version__ = "0.1.2"
